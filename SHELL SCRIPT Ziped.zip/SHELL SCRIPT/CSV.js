document.getElementById('processButton').addEventListener('click', () => {
    const fileInput = document.getElementById('fileInput');
    const file = fileInput.files[0];
    const reader = new FileReader();

    reader.onload = () => {
        const data = reader.result;
        processData(data);
    };

    reader.readAsText(file);
});

function processData(data) {
    const lines = data.split('\n');
    let output = {};

    lines.forEach(line => {
        const [url, title] = line.split(',');

        if (url && title) {
            const category = categorizeURL(url.trim());
            if (!output[category]) {
                output[category] = [];
            }
            output[category].push(title.trim());
        }
    });

    displayOutput(output);
}

function categorizeURL(url) {
    if (url.includes('/ai')) {
        return 'AI';
    } else if (url.includes('/php')) {
        return 'PHP';
    } else if (url.includes('/python')) {
        return 'Python';
    } else {
        return 'Other';
    }
}

function displayOutput(output) {
    const outputDiv = document.getElementById('output');
    outputDiv.innerHTML = '';

    for (const category in output) {
        const titles = output[category].join(' - ');
        outputDiv.innerHTML += `<h3>${category}</h3><p>${titles}</p>`;
    }
}